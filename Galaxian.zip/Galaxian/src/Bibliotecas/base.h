#ifndef _BASE_H_
#define _BASE_H_

#define LARGURA_MUNDO 480
#define ALTURA_MUNDO 270

#define QTDINIMIGOS_LISTA 5
#define QTD_LISTAINIMIGOS 3

#include <stdlib.h>

enum telas {menu,game,gameOver,gameWon};

typedef struct{
    int x;
    int y;
} Posicao;

typedef struct{
    int altura;
    int largura;
} Dimensao;

typedef struct{
    int vidas;
    int cooldown;
    Posicao posicao;
    Dimensao dimensao;
} Jogador;

typedef struct{
    Posicao posicao;
    Dimensao dimensao;
    int vidas;
} Inimigo;


typedef struct{
    Posicao posicao;
    Dimensao dimensao;
} TiroJogador;

typedef struct{
    Posicao posicao;
    Dimensao dimensao;
} TiroInimigo;

#endif
