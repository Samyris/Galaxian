#include "desenhos.h"
//#include "base.h"
//#include "listas.h"

GLuint menuT, alien, fundo, gameO, nave, pauseT, vidaT, gameW, tiroJT, tiroIT;


GLuint carregaTextura(const char* arquivo){
    GLuint idTextura = SOIL_load_OGL_texture( arquivo, SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y );

    if (idTextura == 0) {
        printf("Erro carregando a textura: '%s'\n", SOIL_last_result());
    }

    return idTextura;
}

void inicializaTextura(){ 
    glDeleteTextures( 1, &nave); 
    nave = carregaTextura("texturas/nave.png");
    glDeleteTextures( 1, &pauseT); 
    pauseT = carregaTextura("texturas/Pause.png");
    glDeleteTextures( 1, &menuT); 
    menuT = carregaTextura("texturas/Inicial.png");
    glDeleteTextures( 1, &alien); 
    alien = carregaTextura("texturas/alien.png");
    glDeleteTextures( 1, &fundo); 
    fundo = carregaTextura("texturas/fundo.png");
    glDeleteTextures( 1, &gameO); 
    gameO = carregaTextura("texturas/Game-over.png");
    glDeleteTextures( 1, &vidaT); 
    vidaT = carregaTextura("texturas/vida.png");
    glDeleteTextures( 1, &gameW); 
    gameW = carregaTextura("texturas/Win.png");
    glDeleteTextures( 1, &tiroJT); 
    tiroJT = carregaTextura("texturas/tiroJogador.png");
    glDeleteTextures( 1, &tiroIT); 
    tiroIT = carregaTextura("texturas/tiroInimigo.png");
}

void desenhaRetangulo(int x, int y, int w, int h) {
  glColor3f(1, 1, 1);
  glBegin(GL_TRIANGLE_FAN);
      glTexCoord2f(0, 0);glVertex2i(x, y);
      glTexCoord2f(1, 0);glVertex2i(x + w, y);
      glTexCoord2f(1, 1);glVertex2i(x + w, y + h);
      glTexCoord2f(0, 1);glVertex2i(x, y + h);
  glEnd();
  //glPolygonMode(GL_FRONT_AND_BACK, GL_POINT);
}

void desenhaTelaRetangulo(int x, int y, int w, int h, int z){
  glColor3f(1, 1, 1);
  glBegin(GL_TRIANGLE_FAN);
      glTexCoord2f(0, 0);glVertex3i(x, y, z);
      glTexCoord2f(1, 0);glVertex3i(x + w, y, z);
      glTexCoord2f(1, 1);glVertex3i(x + w, y + h, z);
      glTexCoord2f(0, 1);glVertex3i(x, y + h, z);
  glEnd();
  //glPolygonMode(GL_FRONT_AND_BACK, GL_POINT);
}

void inicializaJogador(Jogador* jogador){
    jogador->dimensao.largura = 20;
    jogador->dimensao.altura = 20;
    jogador->posicao.x = LARGURA_MUNDO/2 - jogador->dimensao.largura/2;
    jogador->posicao.y = ALTURA_MUNDO/5 - jogador->dimensao.altura/2;
    jogador->cooldown = 500;
    jogador->vidas = 3;
    //jogador->vidas = 3;
    //projeteis do jogador
    //pontuacao?
}

void desenhaJogador(Jogador* jogador){
    glBindTexture(GL_TEXTURE_2D, nave);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    //glColor3f(1, 1, 0);
    glEnable(GL_TEXTURE_2D);
    desenhaRetangulo(jogador->posicao.x, jogador->posicao.y ,
          jogador->dimensao.largura, jogador->dimensao.altura);
    glDisable(GL_TEXTURE_2D);
    //glDisable(GL_TEXTURE_2D);

    glBindTexture(GL_TEXTURE_2D, vidaT);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    //glColor3f(1, 1, 0);
    glEnable(GL_TEXTURE_2D);
    //glColor3f(1, 0, 0);
    for(int i=0, j=0;i<jogador->vidas;i++,j+=20){
      desenhaTelaRetangulo(LARGURA_MUNDO/2-25+j, ALTURA_MUNDO/12 - 5 , 10, 10,1);
    }
    glDisable(GL_TEXTURE_2D);
}


//apenas inicia, tiros sao criados apartir de atualizaJogador() em fisica
void inicializaTirosJ(TipoListaTiro* tiroJ){
    FLvaziaT(tiroJ);
}

void desenhaTirosJ(TipoListaTiro* tiroJ){
    TipoCelulaTiro *Aux;
    Aux = tiroJ->Primeiro->Prox;
        while(Aux != NULL){
            glBindTexture(GL_TEXTURE_2D, tiroJT);
            glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
            glEnable(GL_TEXTURE_2D);
            desenhaRetangulo(Aux->tiro.posicao.x, Aux->tiro.posicao.y ,
                    Aux->tiro.dimensao.largura, Aux->tiro.dimensao.altura);
            glDisable(GL_TEXTURE_2D);
            Aux = Aux->Prox;
    }
}

void inicializaInimigos(TipoListaInimigo inimigos[]){
    for(int i = 0; i<QTD_LISTAINIMIGOS; i++){
      FLvazia(&inimigos[i]);
    }
    #define DISTANCIAY_INIMIGOS 40
    #define DISTANCIAX_INIMIGOS 85
    Inimigo inimigo;
    inimigo.dimensao.largura = 13;
    inimigo.dimensao.altura = 13;
    inimigo.posicao.x = LARGURA_MUNDO/8 - inimigo.dimensao.largura/2;
    inimigo.posicao.y = 9*ALTURA_MUNDO/10 - inimigo.dimensao.altura/2;
    //Insere os Inimigos para cada uma das listas de inimigo
    for(int j=0, cont=QTD_LISTAINIMIGOS;j<QTD_LISTAINIMIGOS;j++,cont--){
      for(int k=0; k<QTDINIMIGOS_LISTA; k++){
        inimigo.vidas=cont;
        inimigo.dimensao.largura = 13 + 5*cont;
        inimigo.dimensao.altura = 13 + 5*cont;
        Insere(inimigo,&inimigos[j]);
        inimigo.posicao.x += DISTANCIAX_INIMIGOS;
      }
      //cada lista comeca do mesmo x
      inimigo.posicao.x = LARGURA_MUNDO/8 - inimigo.dimensao.largura/2;
      //cada lista fica mais abaixo no y
      inimigo.posicao.y -= DISTANCIAY_INIMIGOS;
    }
}

void desenhaInimigos(TipoListaInimigo inimigos[]){
  TipoCelulaInimigo *Aux;
  for(int i = 0; i<QTD_LISTAINIMIGOS; i++){
      Aux = inimigos[i].Primeiro->Prox;
      while(Aux != NULL){
        glBindTexture(GL_TEXTURE_2D, alien);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        //glColor3f(1, 1, 0);
        glEnable(GL_TEXTURE_2D);
        desenhaRetangulo(Aux->inimigo.posicao.x, Aux->inimigo.posicao.y ,
        Aux->inimigo.dimensao.largura, Aux->inimigo.dimensao.altura);
        glDisable(GL_TEXTURE_2D);
      Aux = Aux->Prox;
      }
    }
}

//apenas inicia, tiros sao criados apartir de atualizaInimigos() em fisica
void inicializaTirosI(TipoListaTiroI* tiroI){
  FLvaziaTI(tiroI);
}

void desenhaTirosI(TipoListaTiroI* tiroI){
    TipoCelulaTiroI *Aux;
    Aux = tiroI->Primeiro->Prox;
        while(Aux != NULL){
            glBindTexture(GL_TEXTURE_2D, tiroIT);
            glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
            glEnable(GL_TEXTURE_2D);
            desenhaRetangulo(Aux->tiro.posicao.x, Aux->tiro.posicao.y ,
                    Aux->tiro.dimensao.largura, Aux->tiro.dimensao.altura);
            glDisable(GL_TEXTURE_2D);
            Aux = Aux->Prox;
    }
}

void desenhaPause(){
    //glColor3f(1, 0, 1);
    glBindTexture(GL_TEXTURE_2D, pauseT);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    //glColor3f(1, 1, 0);
    glEnable(GL_TEXTURE_2D);
    desenhaTelaRetangulo(0,0,LARGURA_MUNDO,ALTURA_MUNDO,2);
    glDisable(GL_TEXTURE_2D);
}
void desenhaMenu(){
    glColor3f(0, 0, 1);
    glBindTexture(GL_TEXTURE_2D, menuT);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    //glColor3f(1, 1, 0);
    glEnable(GL_TEXTURE_2D);
    desenhaTelaRetangulo(0,0,LARGURA_MUNDO,ALTURA_MUNDO,2);
    glDisable(GL_TEXTURE_2D);

}
void desenhaGameOver(){
    //glColor3f(1, 0, 0);
    glBindTexture(GL_TEXTURE_2D, gameO);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    //glColor3f(1, 1, 0);
    glEnable(GL_TEXTURE_2D);
    desenhaTelaRetangulo(0,0,LARGURA_MUNDO,ALTURA_MUNDO,2);
    glDisable(GL_TEXTURE_2D);
}
void desenhaGameWon(){
    //glColor3f(0, 1, 1);
    glBindTexture(GL_TEXTURE_2D, gameW);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    //glColor3f(1, 1, 0);
    glEnable(GL_TEXTURE_2D);
    desenhaTelaRetangulo(0,0,LARGURA_MUNDO,ALTURA_MUNDO,2);
    glDisable(GL_TEXTURE_2D);
}

void desenhaFundo(){
    //glColor3f(0, 1, 1);
    glBindTexture(GL_TEXTURE_2D, fundo);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    //glColor3f(1, 1, 0);
    glEnable(GL_TEXTURE_2D);
    desenhaTelaRetangulo(0,0,LARGURA_MUNDO,ALTURA_MUNDO,-1);
    glDisable(GL_TEXTURE_2D);
}