#ifndef _DESENHOS_H_
#define _DESENHOS_H_

#include "base.h"
#include "listas.h"
#include <stdio.h>
#include <SOIL/SOIL.h>
#include <GL/glew.h>
#include <GL/freeglut.h>

void inicializaTextura();
GLuint carregaTextura(const char* arquivo);
void desenhaRetangulo(int x, int y, int w, int h);
void desenhaTelaRetangulo(int x, int y, int w, int h, int z);
void desenhaJogador(Jogador* jogador);
void inicializaJogador(Jogador* jogador);
void inicializaTirosJ(TipoListaTiro* tiroJ);
void desenhaTirosJ(TipoListaTiro* tiroJ);
void inicializaInimigos(TipoListaInimigo inimigos[]);
void inicializaTirosI(TipoListaTiroI* tiroI);
void desenhaInimigos(TipoListaInimigo inimigos[]);
void desenhaTirosI(TipoListaTiroI* tiroI);
void desenhaFundo();
void desenhaPause();
void desenhaMenu();
void desenhaGameOver();
void desenhaGameWon();

#endif