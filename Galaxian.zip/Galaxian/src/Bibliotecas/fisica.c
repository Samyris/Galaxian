#include <GL/glew.h>
#include <GL/freeglut.h>

#include "fisica.h"
#include "base.h"
#include <stdio.h>//temp

#include <stdbool.h>

void atualizaJogador(Jogador *jogador, bool *keystates, TipoListaTiro *tiroJ,
                        TipoListaTiroI *tirosI){
    //largura da tela: 480
    int timeSinceStart = glutGet(GLUT_ELAPSED_TIME);
    if (keystates[GLUT_KEY_LEFT] /*&& jogador->vidas > 0*/ &&jogador->posicao.x > 1 ){
        jogador->posicao.x -= 5;
    }
    if (keystates[GLUT_KEY_RIGHT] /*&& jogador->vidas > 0*/ &&
         (jogador->posicao.x + jogador->dimensao.largura) < 480){
        jogador->posicao.x += 5;
    }
    if (keystates[' ']&&(timeSinceStart-tiroJ->timeLastShot)>jogador->cooldown){
        int timeSinceStart = glutGet(GLUT_ELAPSED_TIME);
        tiroJ->timeLastShot = timeSinceStart;
        TiroJogador tiro;
        tiro.dimensao.altura = 5;
        tiro.dimensao.largura = 5;
        tiro.posicao.x = jogador->posicao.x + jogador->dimensao.largura/2;
        tiro.posicao.y = jogador->posicao.y + jogador->dimensao.altura;
        InsereT(tiro,tiroJ);
    }
}

void colisaoJogador(Jogador *jogador, TipoListaTiroI *tiroI){
    TipoCelulaTiroI *Aux;
    TipoCelulaTiroI *Aux2;
    //Para remover o tiro que colide visto por Aux, RetiraTI() precisa receber
    //a celula anterior a ele, vista por Aux2
    Aux = tiroI->Primeiro->Prox;
    Aux2 = tiroI->Primeiro;
        while(Aux != NULL){
            if(Aux->tiro.posicao.y <= jogador->posicao.y+jogador->dimensao.altura &&
                Aux->tiro.posicao.x+Aux->tiro.dimensao.largura>=jogador->posicao.x &&
                Aux->tiro.posicao.x<=jogador->posicao.x+jogador->dimensao.largura){
                    jogador->vidas--;
                    RetiraTI(Aux2,tiroI);
                    ///atualizar AuxT, a celula que ele apontava foi deletada
                    Aux = Aux2->Prox;
            }
            else{
                Aux2 = Aux;
                Aux = Aux->Prox;
            }
    }
}

void atualizaTiroJ(TipoListaTiro *tiroJ, TipoListaInimigo inimigos[],
                    Jogador *jogador){
    TipoCelulaTiro *Aux;
    if(!VaziaT(*tiroJ)){
        Aux = tiroJ->Primeiro->Prox;
        while(Aux != NULL){
            Aux->tiro.posicao.y += 3;
            Aux = Aux->Prox;
        }
        //colisaoTiroJogador_eInimigo(inimigos, tiroJ, jogador);
        colisaoTiroJTeto(tiroJ);
        colisaoTiroJInimigo(tiroJ,inimigos);
    }
}

void colisaoTiroJTeto(TipoListaTiro *tirosJ){
    TipoCelulaTiro *AuxT;
    AuxT = tirosJ->Ultimo;
    if(AuxT->tiro.posicao.y+AuxT->tiro.dimensao.altura>=480-2){
        TipoCelulaTiro *AuxT2;
        AuxT = tirosJ->Primeiro->Prox;
        AuxT2 = tirosJ->Primeiro;
        while(AuxT != NULL){
            if(AuxT->tiro.posicao.y+AuxT->tiro.dimensao.altura>=480-2){
                RetiraT(AuxT2, tirosJ);
                ///atualizar AuxT, a celula que ele apontava foi deletada
                AuxT = AuxT2->Prox;
            }
            else{
                AuxT2 = AuxT;
                AuxT = AuxT->Prox;
            }
        }
    }
}

void colisaoTiroJInimigo(TipoListaTiro *tirosJ,TipoListaInimigo inimigos[]){
    //Checa colisoes com os inimigos do tirosJogador
    TipoCelulaTiro *AuxT;
    TipoCelulaTiro *AuxT2;
    TipoCelulaInimigo *Aux;
    TipoCelulaInimigo *Aux2;

    for(int i=2;i>=0;i--){
        Aux = inimigos[i].Primeiro->Prox;
        Aux2 = inimigos[i].Primeiro;
        while(Aux != NULL){
            bool coli = false;
            //Checa colisao de todos os tiros com os inimigos dessa lista
            for(AuxT = tirosJ->Primeiro->Prox,AuxT2=tirosJ->Primeiro ;AuxT!=NULL;
                    AuxT = AuxT->Prox, AuxT2 = AuxT2->Prox){
                if(AuxT->tiro.posicao.y+AuxT->tiro.dimensao.altura>=Aux->inimigo.posicao.y &&
                AuxT->tiro.posicao.y<=Aux->inimigo.posicao.y+Aux->inimigo.dimensao.largura &&
                AuxT->tiro.posicao.x+AuxT->tiro.dimensao.largura>=Aux->inimigo.posicao.x &&
                AuxT->tiro.posicao.x<=Aux->inimigo.posicao.x+Aux->inimigo.dimensao.largura){
                    Aux->inimigo.vidas--;
                    Aux->inimigo.dimensao.largura -= 5;
                    Aux->inimigo.dimensao.altura -= 5;
                    if(Aux->inimigo.vidas==0){
                        Retira(Aux2,&inimigos[i]);
                        ///atualizar Aux(Inimigo),a celula que ele apontava foi deletada
                        Aux = Aux2->Prox;
                    }
                    RetiraT(AuxT2,tirosJ);
                    bool coli = true;
                    break; //esse inimigo nao consegue mais ser atingido 
                }
                
            }
            //Caso n aja colisao, deve-se checar o novo valor de aux
            if(!coli && Aux!=NULL){
                Aux2 = Aux2->Prox;
                Aux = Aux->Prox;
                coli = false;
            }
        }
    }
}

void atualizaInimigos(TipoListaInimigo inimigos[], TipoListaTiroI *tiroI ,
                        Jogador *jogador){
    TipoCelulaInimigo *Aux;
    for(int i=0;i<QTD_LISTAINIMIGOS;i++){
        if(!Vazia(*&inimigos[i])){
            Aux = inimigos[i].Primeiro->Prox;
            while(Aux != NULL){
                //Movimento do inimigo
                Aux->inimigo.posicao.x += inimigos[i].vel_inimigo;
                //chance do inimigo atirar
                int r = rand() % 2000;
                if(r < 5){
                    TiroInimigo tiro;
                    tiro.dimensao.altura = 3;
                    tiro.dimensao.largura = 3;
                    tiro.posicao.x = Aux->inimigo.posicao.x + Aux->inimigo.dimensao.largura/2;
                    tiro.posicao.y = Aux->inimigo.posicao.y - tiro.dimensao.altura;
                    InsereTI(tiro,tiroI);
                }
                Aux = Aux->Prox;
            }
            colisaoInimigosMargem(&inimigos[i], jogador, inimigos);
            colisaoInimigosJogador(&inimigos[i],jogador);
        }
    }
}

void colisaoInimigosMargem(TipoListaInimigo *inimigos, Jogador *jogador, TipoListaInimigo inimigosV[]){
    TipoCelulaInimigo *Aux;
    Aux = inimigos->Primeiro->Prox;
    if(Aux->inimigo.posicao.x <= 0+3){
        //int qtdInimigos = QtdInimigosLista(inimigos);
        inimigos->vel_inimigo *= -1;
        desceInimigos(inimigosV);
    }
    else{
        Aux = inimigos->Ultimo;
        if(Aux->inimigo.posicao.x >= 480-3){
            //int qtdInimigos = QtdInimigosLista(inimigos);
            inimigos->vel_inimigo *= -1;
            desceInimigos(inimigosV);
        }
    }
}

void desceInimigos(TipoListaInimigo inimigos[]){
    TipoCelulaInimigo *Aux;
    for(int i=0;i<QTD_LISTAINIMIGOS;i++){
        Aux = inimigos[i].Primeiro->Prox;
        while(Aux!=NULL){
            Aux->inimigo.posicao.y -= 1;
            Aux = Aux->Prox;
        }
    }
}

void colisaoInimigosJogador(TipoListaInimigo *inimigos, Jogador *jogador){
    TipoCelulaInimigo *Aux;
    TipoCelulaInimigo *Aux2;
    Aux = inimigos->Primeiro->Prox;
    Aux2 = inimigos->Primeiro;
    //Jogador bate com a nave em um inimigo
    while(Aux != NULL){
        if(Aux->inimigo.posicao.y <= jogador->posicao.y+jogador->dimensao.altura &&
                Aux->inimigo.posicao.x+Aux->inimigo.dimensao.largura>=jogador->posicao.x &&
                Aux->inimigo.posicao.x<=jogador->posicao.x+jogador->dimensao.largura&&
                Aux->inimigo.posicao.y+Aux->inimigo.dimensao.altura>= jogador->posicao.y){
                    ///atualizar Aux, a celula que ele apontava foi deletada
                    Retira(Aux2,inimigos);
                    Aux = Aux2->Prox;
                    jogador->vidas--;
        }
        else{
            Aux2 = Aux;
            Aux = Aux->Prox;
        }
    }

}

void colisaoInimigosChao(TipoListaInimigo *inimigos, Jogador *jogador){
    TipoCelulaInimigo *Aux;
    Aux = inimigos->Primeiro->Prox;
    while(Aux != NULL){
        if(Aux->inimigo.posicao.y <= 3){
            jogador->vidas = 0;
        }
        Aux = Aux->Prox;
    }
}


void atualizaTiroI(TipoListaTiroI *tiroI, Jogador *jogador){
    if(!VaziaTI(*tiroI)){
        TipoCelulaTiroI *Aux;
        Aux = tiroI->Primeiro->Prox;
        while(Aux != NULL){
            Aux->tiro.posicao.y -= 1;
            Aux = Aux->Prox;
        }
        colisaoTiroI_Jogador(tiroI, jogador);
        colisaoTiroI_Chao(tiroI);
    }
}

void colisaoTiroI_Jogador(TipoListaTiroI *tirosI, Jogador *jogador){
    TipoCelulaTiroI *Aux;
    TipoCelulaTiroI *Aux2;
    //Para remover o tiro que colide visto por Aux, RetiraTI() precisa receber
    //a celula anterior a ele, vista por Aux2
    Aux = tirosI->Primeiro->Prox;
    Aux2 = tirosI->Primeiro;
        while(Aux != NULL){
            if(Aux->tiro.posicao.y <= jogador->posicao.y+jogador->dimensao.altura &&
                Aux->tiro.posicao.x+Aux->tiro.dimensao.largura>=jogador->posicao.x &&
                Aux->tiro.posicao.x<=jogador->posicao.x+jogador->dimensao.largura &&
                Aux->tiro.posicao.y+Aux->tiro.dimensao.altura>= jogador->posicao.y){
                    jogador->vidas--;
                    RetiraTI(Aux2,tirosI);
                    ///atualizar AuxT, a celula que ele apontava foi deletada
                    Aux = Aux2->Prox;
            }
            else{
                Aux2 = Aux;
                Aux = Aux->Prox;
            }

    }
}

void colisaoTiroI_Chao(TipoListaTiroI *tirosI){
    TipoCelulaTiroI *AuxT;
    AuxT = tirosI->Primeiro->Prox;
    TipoCelulaTiroI *AuxT2;
    AuxT2 = tirosI->Primeiro;
    while(AuxT != NULL){
        if(AuxT->tiro.posicao.y<=0+2){
            RetiraTI(AuxT2, tirosI);
            //Precisa atualizar AuxT, ja que a celula que ele apontava
            //foi deletada
            AuxT = AuxT2->Prox;
        }
        else{
            AuxT2 = AuxT;
            AuxT = AuxT->Prox;
        }
    }
}