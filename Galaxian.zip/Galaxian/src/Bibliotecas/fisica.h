#ifndef _FISICA_H_
#define _FISICA_H_

#include <stdbool.h>

#include "base.h"
#include "listas.h"


void atualizaJogador(Jogador *jogador, bool *keystates, TipoListaTiro *tirosJ,
                        TipoListaTiroI *tirosI);

void atualizaTiroJ(TipoListaTiro *tiroJ, TipoListaInimigo inimigos[],
                    Jogador *jogador);
void colisaoTiroJTeto(TipoListaTiro *tirosJ);
void colisaoTiroJInimigo(TipoListaTiro *tirosJ,TipoListaInimigo inimigos[]);

void atualizaInimigos(TipoListaInimigo inimigos[], TipoListaTiroI *tiroI,
                        Jogador * jogador);
void colisaoInimigosJogador(TipoListaInimigo *inimigos, Jogador *jogador);
void colisaoInimigosMargem(TipoListaInimigo *inimigos, Jogador *jogador, TipoListaInimigo inimigosV[]);
void desceInimigos(TipoListaInimigo inimigos[]);
void colisaoInimigosChao(TipoListaInimigo *inimigos, Jogador *jogador);
void atualizaTiroI(TipoListaTiroI *tiroI, Jogador *jogador);
void colisaoTiroI_Jogador(TipoListaTiroI *tirosI, Jogador *jogador);
void colisaoTiroI_Chao(TipoListaTiroI *tirosI);
//void colisaoTiroJogador_eInimigo(TipoListaInimigo inimigos[], TipoListaTiro *tiroJ,
//        Jogador *jogador);

#endif