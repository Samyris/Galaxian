#include <GL/glew.h>
#include <GL/freeglut.h>

#include <stdlib.h>
#include <stdio.h>

#include "listas.h"
#include "base.h"

void FLvazia(TipoListaInimigo *Lista){
    Lista -> Primeiro = (TipoCelulaInimigo*) malloc(sizeof(TipoCelulaInimigo));
    Lista -> Ultimo = Lista -> Primeiro;
    Lista -> Primeiro -> Prox = NULL;
    Lista -> vel_inimigo = 3;
}
int Vazia(TipoListaInimigo Lista){
    return (Lista.Primeiro == Lista.Ultimo);
}
int QtdInimigosLista(TipoListaInimigo *Lista){
    if(Vazia(*Lista)){
        return 0;
    }
    TipoCelulaInimigo *Aux;
    int contIni = 0;
    Aux = Lista->Primeiro->Prox;
    while(Aux != NULL){
        contIni++;
        Aux = Aux->Prox;
    }
    return contIni;
}
void Insere(Inimigo x, TipoListaInimigo *Lista){
    Lista -> Ultimo -> Prox = (TipoCelulaInimigo *)malloc(sizeof(TipoCelulaInimigo));
    Lista -> Ultimo = Lista -> Ultimo -> Prox;
    Lista -> Ultimo -> inimigo = x;
    Lista -> Ultimo -> Prox = NULL;
}
void Retira(TipoCelulaInimigo *p, TipoListaInimigo *Lista/*, Inimigo *Item*/){
    /*---Obs.: o item a ser retirado e o seguinte ao apontado por  p --- */
    TipoCelulaInimigo *q;

    if (Vazia(*Lista) || p == NULL || p -> Prox == NULL) 
    { printf("Erro : ListaInimigo vazia ou posicao nao existe\n");
      return;
    }
    q = p -> Prox;
    //*Item = q -> inimigo;
    p -> Prox = q -> Prox;
    if (p -> Prox == NULL)
    Lista -> Ultimo = p;
    free(q);
}

//Tiro Jogador

void FLvaziaT(TipoListaTiro *Lista){
    Lista -> Primeiro = (TipoCelulaTiro*) malloc(sizeof(TipoCelulaTiro));
    Lista -> Ultimo = Lista -> Primeiro;
    Lista -> Primeiro -> Prox = NULL;
    Lista -> timeLastShot = 0;
}

int VaziaT(TipoListaTiro Lista){
    return (Lista.Primeiro == Lista.Ultimo);
}

void InsereT(TiroJogador x, TipoListaTiro *Lista){
    Lista -> Ultimo -> Prox = (TipoCelulaTiro *)malloc(sizeof(TipoCelulaTiro));
    Lista -> Ultimo = Lista -> Ultimo -> Prox;
    Lista -> Ultimo -> tiro = x;
    Lista -> Ultimo -> Prox = NULL;
}

void RetiraT(TipoCelulaTiro *p, TipoListaTiro *Lista/*, Inimigo *Item*/){
    TipoCelulaTiro *q;

    if (VaziaT(*Lista) || p == NULL || p -> Prox == NULL) 
    { printf("Erro : ListaTiroJ vazia ou posicao nao existe\n");
      return;
    }
    q = p -> Prox;
    //*Item = q -> inimigo;
    p -> Prox = q -> Prox;
    if (p -> Prox == NULL)
    Lista -> Ultimo = p;
    free(q);
}

//Tiro Inimigo

void FLvaziaTI(TipoListaTiroI *Lista){
    Lista -> Primeiro = (TipoCelulaTiroI*) malloc(sizeof(TipoCelulaTiroI));
    Lista -> Ultimo = Lista -> Primeiro;
    Lista -> Primeiro -> Prox = NULL;
}
int VaziaTI(TipoListaTiroI Lista){
    return (Lista.Primeiro == Lista.Ultimo);
}
void InsereTI(TiroInimigo x, TipoListaTiroI *Lista){
    Lista -> Ultimo -> Prox = (TipoCelulaTiroI *)malloc(sizeof(TipoCelulaTiroI));
    Lista -> Ultimo = Lista -> Ultimo -> Prox;
    Lista -> Ultimo -> tiro = x;
    Lista -> Ultimo -> Prox = NULL;
}
void RetiraTI(TipoCelulaTiroI *p, TipoListaTiroI *Lista/*, Inimigo *Item*/){
    TipoCelulaTiroI *q;

    if (VaziaTI(*Lista) || p == NULL || p -> Prox == NULL) 
    { printf("Erro : ListaTiroI vazia ou posicao nao existe\n");
      return;
    }
    q = p -> Prox;
    //*Item = q -> inimigo;
    p -> Prox = q -> Prox;
    if (p -> Prox == NULL)
    Lista -> Ultimo = p;
    free(q);
}