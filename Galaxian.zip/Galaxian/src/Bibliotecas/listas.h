#ifndef _LISTAS_H_
#define _LISTAS_H_


#include "base.h"

/*typedef struct{
    Posicao posicao;
    Dimensao dimensao;
} Inimigo;*/

typedef struct TipoCelulaInimigo {
    Inimigo inimigo;
    struct TipoCelulaInimigo *Prox;
}TipoCelulaInimigo;

typedef struct TipoListaInimigo {
    TipoCelulaInimigo *Primeiro, *Ultimo;
    int vel_inimigo;
}TipoListaInimigo;

void FLvazia(TipoListaInimigo *Lista);
int Vazia(TipoListaInimigo Lista);
void Insere(Inimigo x, TipoListaInimigo *Lista);
void Retira(TipoCelulaInimigo *p, TipoListaInimigo *Lista/*, Inimigo *Item*/);
//void Percorre(TipoListaInimigo Lista);

//Listas para tiros jogador
typedef struct TipoCelulaTiro {
    TiroJogador tiro;
    struct TipoCelulaTiro *Prox;
}TipoCelulaTiro;

typedef struct TipoListaTiro {
    TipoCelulaTiro *Primeiro, *Ultimo;
    int timeLastShot;
}TipoListaTiro;


void FLvaziaT(TipoListaTiro *Lista);
int VaziaT(TipoListaTiro Lista);
int QtdInimigosLista(TipoListaInimigo *Lista);
void InsereT(TiroJogador x, TipoListaTiro *Lista);
void RetiraT(TipoCelulaTiro *p, TipoListaTiro *Lista/*, Inimigo *Item*/);

//Lista para tiros Inimigo
typedef struct TipoCelulaTiroI {
    TiroInimigo tiro;
    struct TipoCelulaTiroI *Prox;
}TipoCelulaTiroI;

typedef struct TipoListaTiroI {
    TipoCelulaTiroI *Primeiro, *Ultimo;
}TipoListaTiroI;

void FLvaziaTI(TipoListaTiroI *Lista);
int VaziaTI(TipoListaTiroI Lista);
void InsereTI(TiroInimigo x, TipoListaTiroI *Lista);
void RetiraTI(TipoCelulaTiroI *p, TipoListaTiroI *Lista/*, Inimigo *Item*/);

#endif