/*
 * Trabalho Pratico 1
 * Computacao Grafica
 * 
 * Alunos:  
 *        Eduardo Gomes de Freitas;
 *        Leonardo Gonçalves Grossi;
 *        Luan Felipe Santos Alves;
 *        Samyris Alves Rodrigues.
 *
 */

#include <stdio.h>
#include <GL/glew.h>
#include <GL/freeglut.h>
#include <SOIL/SOIL.h>

#include <stdlib.h>
#include <stdbool.h>
#include <time.h>

#include "Bibliotecas/desenhos.h"
#include "Bibliotecas/base.h"
#include "Bibliotecas/fisica.h"
#include "Bibliotecas/listas.h"

#define LARGURA_MUNDO 480
#define ALTURA_MUNDO 270

Jogador jogador;
TipoListaTiro tirosJ;

Inimigo inimigo;
TipoListaInimigo inimigos1,inimigos2,inimigos3;
TipoListaInimigo *inimigos;
TipoListaTiroI tirosI;
bool keystates[256];
enum telas telaAtual = menu;
bool pause = false;

void setup() {
    glClearColor(1, 1, 1, 0); // branco
    glClear(GL_COLOR_BUFFER_BIT);
    glEnable(GL_BLEND ); 
    glEnable(GL_DEPTH_TEST); 
    glEnable(GL_TEXTURE_2D); 
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    glAlphaFunc(GL_GREATER, 0.5);
    glEnable(GL_ALPHA_TEST);
    inicializaTextura();
    free(inimigos);
    srand(time(0));
    inicializaJogador(&jogador);
    inicializaTirosJ(&tirosJ);
    //aloca espaco em inimigos para guardar os ponteiros para as listas de inimigos
    inimigos = malloc(QTD_LISTAINIMIGOS * sizeof(TipoListaInimigo));
    inimigos[0] = inimigos1;
    inimigos[1] = inimigos2;
    inimigos[2] = inimigos3;
    inicializaInimigos(inimigos);
    inicializaTirosI(&tirosI);
}

void desenhaCena() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    //desenha quadrado vermelho no centro
    //glColor3f(0, 0, 0);
    //glPolygonMode(GL_FRONT_AND_BACK, GL_POINT);
    switch(telaAtual){
        case(game):
        desenhaFundo();
        desenhaJogador(&jogador);
        desenhaTirosJ(&tirosJ);
        desenhaInimigos(inimigos);
        desenhaTirosI(&tirosI);
        if(pause==true){
            desenhaPause();
        }
        break;
        case(menu):
            desenhaMenu();
        break;
        case(gameOver):
            desenhaGameOver();
        break;
        case(gameWon):
            desenhaGameWon();
        break;
    }

    glFlush();
}

void redimensiona(int width, int height) {
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, LARGURA_MUNDO, 0, ALTURA_MUNDO, -5, 5);

    float razaoAspectoJanela = ((float)width)/height;
    float razaoAspectoMundo = ((float) LARGURA_MUNDO)/ ALTURA_MUNDO;
    // se a janela está menos larga do que o mundo (16:9)...
    if (razaoAspectoJanela < razaoAspectoMundo) {
        // vamos colocar barras verticais (acima e abaixo)
        float hViewport = width / razaoAspectoMundo;
        float yViewport = (height - hViewport)/2;
        glViewport(0, yViewport, width, hViewport);
    }
    // se a janela está mais larga (achatada) do que o mundo (16:9)...
    else if (razaoAspectoJanela > razaoAspectoMundo) {
        // vamos colocar barras horizontais (esquerda e direita)
        float wViewport = ((float)height) * razaoAspectoMundo;
        float xViewport = (width - wViewport)/2;
        glViewport(xViewport, 0, wViewport, height);
    } else {
        glViewport(0, 0, width, height);
    }

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void trataTeclado(){
    if(keystates[27]){
        exit(0);
    }
    else{
        switch(telaAtual){
            case(game):
            if(keystates[112]||keystates[80]){
                if(pause==false){
                    pause = true;
                }
                else
                pause = false;
            } else if(keystates[82]||keystates[114]){
                pause = false;
                setup();
            }
            break;
            case(menu):
            if(keystates[13]){
                telaAtual = game;
                setup();
            }
            break;
            default:
            if(keystates[82]||keystates[114]){
                telaAtual = game;
                pause = false;
                setup();
            }
            else if(keystates[13]){
                telaAtual = menu;
                pause = false;
            }
            break;
        }
    }
}

void tecladoSpecial(int key, int x, int y){
    keystates[key] = true;
    trataTeclado();
}

void tecladoSpecialUp(int key, int x, int y){
    keystates[key] = false;
}

void teclado(unsigned char key, int x, int y){
    keystates[key] = true;
    trataTeclado();
    /*if(keystates[112]){
        if(pause==false){
            pause = true;
            desenhaEstado();}
        else if(pause==true)
            pause = false;
    }*/
}

void tecladoUp(unsigned char key, int x, int y){
    keystates[key] = false;
}

void atualizaTelas(){
    if(jogador.vidas<=0){
        telaAtual=gameOver;
    }
    else{
        int cont = 0;
        for(int i=0;i<QTD_LISTAINIMIGOS;i++){
            if(Vazia(*&inimigos[i])){
                cont++;
            }
            else break;
        }
        if(cont==QTD_LISTAINIMIGOS){
            telaAtual=gameWon; //comente isso para fases infinitas
            //inicializaInimigos(inimigos); //Fases infinitas, se vc ta lendo isso da mais 15% Glender, vlw
        }
    }
}

void atualizaQuadros(int periodo){

    if(telaAtual == game && !pause){
        atualizaJogador(&jogador, keystates, &tirosJ, &tirosI);
        atualizaTiroJ(&tirosJ, inimigos, &jogador);
        atualizaInimigos(inimigos, &tirosI, &jogador);
        atualizaTiroI(&tirosI, &jogador);
        atualizaTelas();
    }

    glutPostRedisplay();
    glutTimerFunc(periodo, atualizaQuadros, periodo);
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);

    glutInitContextVersion(1, 1);
    glutInitContextProfile(GLUT_COMPATIBILITY_PROFILE);

    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA | GLUT_DEPTH);
    glutInitWindowSize(480, 270);

    glutCreateWindow("Galaxian");

    // Registra callbacks para eventos
    glutDisplayFunc(desenhaCena);
    glutReshapeFunc(redimensiona);
    glutSpecialFunc(tecladoSpecial);
    glutSpecialUpFunc(tecladoSpecialUp);
    glutKeyboardFunc(teclado);
    glutKeyboardUpFunc(tecladoUp);
    glutIgnoreKeyRepeat(GLUT_KEY_REPEAT_ON);


    glutTimerFunc(0, atualizaQuadros, 30);

    // Configura valor inicial de algumas
    // variáveis de estado do OpenGL
    setup();

    glutMainLoop();
    return 0;
}